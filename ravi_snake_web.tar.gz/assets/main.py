import pygame, random, os, sys, math, asyncio

pygame.init()
pygame.mixer.init()

WIDTH, HEIGHT = 1000, 650
CELL = 25
COLS, ROWS = WIDTH // CELL, HEIGHT // CELL
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ravi Meme Snake")
clock = pygame.time.Clock()

# ---------------- SWIPE CONTROLS (for phones/tablets) ----------------
# Phones have no arrow keys/WASD, so a swipe anywhere on screen steers Ravi.
# A short tap (movement below the threshold) starts/restarts the game
# instead, mirroring SPACE. Keyboard controls still work unchanged.
SWIPE_MIN_PIXELS = 24  # movement shorter than this counts as a tap, not a swipe

def swipe_to_direction(dx, dy):
    if abs(dx) < SWIPE_MIN_PIXELS and abs(dy) < SWIPE_MIN_PIXELS:
        return None  # too short — treat as a tap
    if abs(dx) > abs(dy):
        return (1,0) if dx > 0 else (-1,0)
    else:
        return (0,1) if dy > 0 else (0,-1)

ASSETS = os.path.join(os.path.dirname(__file__), "assets")
BG=(24,34,29); GRID=(20,90,45); GREEN=(70,205,95); HEAD=(120,240,120)
COIN=(255,205,40); WALL=(145,95,55); WALL2=(205,145,75); WHITE=(245,245,245)
RED=(235,65,65); BLACK=(10,10,10)
ENEMY_HEAD=(235,105,105); ENEMY_BODY=(185,55,65)
font=pygame.font.Font(None,36); big=pygame.font.Font(None,68)
tiny=pygame.font.Font(None,22)

# ---------------- VISUAL POLISH HELPERS ----------------
PANEL_BG=(15,20,17,170); PANEL_BORDER=(70,205,95,220)

def build_grass_background():
    """Pre-render a grass field once: a green gradient plus scattered blade
    tufts, so we're not redrawing hundreds of shapes every single frame."""
    surf = pygame.Surface((WIDTH, HEIGHT))
    top = (58,150,60); bottom = (28,95,42)
    for y in range(HEIGHT):
        t = y / HEIGHT
        r = int(top[0]+(bottom[0]-top[0])*t)
        g = int(top[1]+(bottom[1]-top[1])*t)
        b = int(top[2]+(bottom[2]-top[2])*t)
        pygame.draw.line(surf,(r,g,b),(0,y),(WIDTH,y))

    rnd = random.Random(7)  # fixed seed so the texture looks the same every run
    shades = [(40,150,55),(70,180,80),(25,110,42),(90,200,95),(35,130,50)]
    for _ in range(1600):
        gx = rnd.randint(0, WIDTH); gy = rnd.randint(0, HEIGHT)
        shade = rnd.choice(shades)
        h = rnd.randint(4, 9)
        lean = rnd.choice([-3,-2,-1,1,2,3])
        pygame.draw.line(surf, shade, (gx,gy), (gx+lean, gy-h), 1)
        pygame.draw.line(surf, shade, (gx+2,gy), (gx+2+lean, gy-h+2), 1)
    return surf

GRASS_BG = build_grass_background()

def draw_gradient_bg(surf):
    surf.blit(GRASS_BG, (0,0))

VIGNETTE = pygame.Surface((WIDTH,HEIGHT), pygame.SRCALPHA)
for i in range(60):
    a = int(90 * (i/60))
    pygame.draw.rect(VIGNETTE,(0,0,0,a), (i,i,WIDTH-2*i,HEIGHT-2*i), 2)

def draw_text_glow(surf, text, fnt, color, center, glow_color=(0,0,0), glow=3):
    shadow = fnt.render(text, True, glow_color)
    base = fnt.render(text, True, color)
    for dx in range(-glow, glow+1):
        for dy in range(-glow, glow+1):
            if dx==0 and dy==0: continue
            surf.blit(shadow, shadow.get_rect(center=(center[0]+dx,center[1]+dy)))
    surf.blit(base, base.get_rect(center=center))

def draw_panel(surf, rect, radius=12):
    panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(panel, PANEL_BG, panel.get_rect(), border_radius=radius)
    pygame.draw.rect(panel, PANEL_BORDER, panel.get_rect(), 2, border_radius=radius)
    surf.blit(panel, rect.topleft)

def sound(name):
    p=os.path.join(ASSETS,name)
    try: return pygame.mixer.Sound(p) if os.path.exists(p) else None
    except pygame.error: return None

coin_song=sound("coin_song.ogg")
crash_song=sound("crash_meme.ogg")
enemy_crash_song=sound("losing_respect.ogg")
boost_song=sound("speed_boost.ogg")
coin_sound=sound("coin.wav")
bg=os.path.join(ASSETS,"meme_music.ogg")
face=None
FACE_SIZE=int(CELL*2.2)  # bigger than one grid cell so it stands out on the head
try:
    face=pygame.image.load(os.path.join(ASSETS,"ravi_face.png")).convert_alpha()
    face=pygame.transform.smoothscale(face,(FACE_SIZE,FACE_SIZE))
except Exception: pass

def make_circular(img):
    """Crop a square image into a circle using an alpha mask."""
    size = img.get_width()
    mask = pygame.Surface((size, size), pygame.SRCALPHA)
    pygame.draw.circle(mask, (255, 255, 255, 255), (size // 2, size // 2), size // 2)
    result = img.copy()
    result.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return result

enemy_face=None
try:
    enemy_face=pygame.image.load(os.path.join(ASSETS,"enemy_face.jpg")).convert_alpha()
    enemy_face=pygame.transform.smoothscale(enemy_face,(FACE_SIZE,FACE_SIZE))
    enemy_face=make_circular(enemy_face)
except Exception: pass

def make_walls():
    patterns=[
        [(8,7,5,1),(25,14,1,5),(14,21,5,1),(32,7,1,5)],
        [(7,10,1,5),(16,6,5,1),(27,20,5,1),(35,10,1,5)],
        [(9,7,5,1),(25,7,5,1),(18,18,1,5),(28,24,5,1)]
    ]
    walls=set()
    for x,y,w,h in random.choice(patterns):
        for a in range(w):
            for b in range(h): walls.add((x+a,y+b))
    return walls

def new_coin(snake,walls):
    free=[(x,y) for y in range(ROWS) for x in range(COLS)
          if (x,y) not in set(snake) and (x,y) not in walls]
    return random.choice(free)

CYAN=(70,220,235)
NORMAL_MOVE_MS = 115
BOOST_MOVE_MS = 55
BOOST_DURATION_MS = 5000

def new_booster(snake, walls, coin, enemy_snake):
    excluded = set(snake) | set(walls) | set(enemy_snake) | {coin}
    free = [(x,y) for y in range(ROWS) for x in range(COLS) if (x,y) not in excluded]
    return random.choice(free) if free else None

def lerp_cell(prev, cur, t):
    """Interpolate between two grid cells for smooth on-screen gliding.
    If the jump is more than one cell (wrap-around at an edge), snap
    instantly on that axis instead of sliding all the way across the board."""
    px, py = prev; cx, cy = cur
    dx = cx - px; dy = cy - py
    if abs(dx) > 1: px = cx; dx = 0
    if abs(dy) > 1: py = cy; dy = 0
    return (px + dx*t, py + dy*t)

def new_enemy(snake, walls):
    occupied = set(snake) | set(walls)
    free = [(x,y) for y in range(ROWS) for x in range(COLS)
            if (x,y) not in occupied]
    if not free:
        return [(2,2),(1,2),(0,2)], (1,0)

    for _ in range(200):
        hx, hy = random.choice(free)
        d = random.choice([(1,0),(-1,0),(0,1),(0,-1)])
        body = [(hx,hy)]
        ok = True
        for i in range(1,4):
            p = (hx-d[0]*i, hy-d[1]*i)
            if p in occupied or not (0 <= p[0] < COLS and 0 <= p[1] < ROWS):
                ok = False
                break
            body.append(p)
        if ok:
            return body, d

    return [(2,2),(1,2),(0,2)], (1,0)

def move_enemy():
    global enemy_snake, enemy_direction

    hx, hy = enemy_snake[0]

    # Randomly turn, but never immediately reverse direction.
    if random.random() < 0.28:
        choices = [(1,0),(-1,0),(0,1),(0,-1)]
        reverse = (-enemy_direction[0], -enemy_direction[1])
        choices = [d for d in choices if d != reverse]
        random.shuffle(choices)

        for d in choices:
            nx, ny = (hx+d[0]) % COLS, (hy+d[1]) % ROWS
            if (nx, ny) not in walls and (nx, ny) not in enemy_snake:
                enemy_direction = d
                break

    dx, dy = enemy_direction
    head = ((hx+dx) % COLS, (hy+dy) % ROWS)

    # If it would enter a wall or itself, choose a safe random direction.
    if head in walls or head in enemy_snake:
        choices = [(1,0),(-1,0),(0,1),(0,-1)]
        random.shuffle(choices)
        reverse = (-enemy_direction[0], -enemy_direction[1])
        for d in choices:
            if d == reverse:
                continue
            nx, ny = (hx+d[0]) % COLS, (hy+d[1]) % ROWS
            if (nx, ny) not in walls and (nx, ny) not in enemy_snake:
                enemy_direction = d
                head = (nx, ny)
                break

    enemy_snake.insert(0, head)
    enemy_snake.pop()

def reset():
    global snake,direction,next_direction,coin,walls,score,game_over,music_playing,enemy_snake,enemy_direction,enemy_move_counter,coin_song_playing,booster,boost_until,prev_snake,last_move_time,current_move_interval,prev_enemy_snake,last_enemy_move_time
    snake=[(COLS//2,ROWS//2),(COLS//2-1,ROWS//2),(COLS//2-2,ROWS//2)]
    walls=make_walls()
    while any(p in walls for p in snake): walls=make_walls()
    direction=(1,0); next_direction=(1,0); score=0; game_over=False
    coin=new_coin(snake,walls); music_playing=False
    enemy_snake, enemy_direction = new_enemy(snake, walls)
    enemy_move_counter = 0
    coin_song_playing=False
    booster = new_booster(snake, walls, coin, enemy_snake)
    boost_until = 0
    pygame.time.set_timer(MOVE, NORMAL_MOVE_MS)
    current_move_interval = NORMAL_MOVE_MS
    prev_snake = list(snake)
    last_move_time = pygame.time.get_ticks()
    prev_enemy_snake = list(enemy_snake)
    last_enemy_move_time = pygame.time.get_ticks()

def start_music():
    global music_playing
    try:
        pygame.mixer.music.load(bg); pygame.mixer.music.set_volume(.55)
        pygame.mixer.music.play(-1); music_playing=True
    except pygame.error: pass

coin_song_playing = False

MOVE=pygame.USEREVENT+1
reset(); started=False
swipe_start=None  # tracks an in-progress touch/mouse drag, for swipe detection
pygame.time.set_timer(MOVE,NORMAL_MOVE_MS)
RESUME=pygame.USEREVENT+2
ENEMY_MOVE=pygame.USEREVENT+3
ENEMY_MOVE_MS = 170
pygame.time.set_timer(ENEMY_MOVE,ENEMY_MOVE_MS)

async def main():
    global started, direction, \
           next_direction, game_over, music_playing, coin_song_playing, \
           prev_snake, score, coin, booster, boost_until, \
           current_move_interval, prev_enemy_snake, last_enemy_move_time, \
           last_move_time, swipe_start

    while True:
        for e in pygame.event.get():
            if e.type==pygame.QUIT:
                pygame.mixer.music.stop(); pygame.quit(); sys.exit()
            if e.type==pygame.KEYDOWN:
                if e.key==pygame.K_ESCAPE:
                    pygame.mixer.music.stop(); pygame.quit(); sys.exit()
                if e.key==pygame.K_SPACE:
                    if not started or game_over:
                        reset(); started=True; start_music()
                nd=None
                if e.key in (pygame.K_UP,pygame.K_w): nd=(0,-1)
                elif e.key in (pygame.K_DOWN,pygame.K_s): nd=(0,1)
                elif e.key in (pygame.K_LEFT,pygame.K_a): nd=(-1,0)
                elif e.key in (pygame.K_RIGHT,pygame.K_d): nd=(1,0)
                if nd and nd != (-direction[0],-direction[1]): next_direction=nd

            # Touch/mouse: remember where a press started.
            if e.type in (pygame.MOUSEBUTTONDOWN, pygame.FINGERDOWN):
                if e.type==pygame.FINGERDOWN:
                    swipe_start=(e.x*WIDTH, e.y*HEIGHT)
                else:
                    swipe_start=e.pos

            # Touch/mouse release: a long enough drag is a swipe (steers);
            # a short one is a tap, which starts/restarts (mirrors SPACE).
            if e.type in (pygame.MOUSEBUTTONUP, pygame.FINGERUP) and swipe_start is not None:
                if e.type==pygame.FINGERUP:
                    end_pos=(e.x*WIDTH, e.y*HEIGHT)
                else:
                    end_pos=e.pos
                dx = end_pos[0]-swipe_start[0]
                dy = end_pos[1]-swipe_start[1]
                nd = swipe_to_direction(dx, dy)
                swipe_start=None
                if nd:
                    if started and not game_over and nd != (-direction[0],-direction[1]):
                        next_direction=nd
                elif not started or game_over:
                    reset(); started=True; start_music()

            if e.type==MOVE and started and not game_over:
                direction=next_direction
                hx,hy=snake[0]; dx,dy=direction
                # Empty edges wrap to the opposite side.
                head=((hx+dx)%COLS,(hy+dy)%ROWS)
                if head in walls or head in snake or head in enemy_snake:
                    game_over=True
                    pygame.mixer.music.stop()
                    music_playing=False
                    coin_song_playing=False
                    if coin_song: coin_song.stop()
                    if head in enemy_snake:
                        if enemy_crash_song: enemy_crash_song.play()
                    elif crash_song:
                        crash_song.play()
                else:
                    prev_snake = list(snake)  # snapshot BEFORE this tick's move, for smooth interpolation
                    snake.insert(0,head)
                    if head==coin:
                        score += 1

                        # Play the coin meme only once at a time.
                        # A second coin collected while it is playing will NOT
                        # restart or overlap the song.
                        if not coin_song_playing:
                            coin_song_playing = True
                            if music_playing:
                                pygame.mixer.music.pause()
                            if coin_song:
                                coin_song.play()
                            elif coin_sound:
                                coin_sound.play()

                        coin = new_coin(snake, walls)
                    elif booster is not None and head==booster:
                        if boost_song: boost_song.play()
                        boost_until = pygame.time.get_ticks() + BOOST_DURATION_MS
                        pygame.time.set_timer(MOVE, BOOST_MOVE_MS)
                        current_move_interval = BOOST_MOVE_MS
                        booster = new_booster(snake, walls, coin, enemy_snake)
                        snake.pop()
                    else:
                        snake.pop()

                    # Snake grew by one (coin) — pad prev_snake so lengths match;
                    # the new tail segment will glide in from the old tail spot.
                    if len(prev_snake) < len(snake):
                        prev_snake += [prev_snake[-1]] * (len(snake) - len(prev_snake))
                    last_move_time = pygame.time.get_ticks()

            if e.type==ENEMY_MOVE and started and not game_over:
                prev_enemy_snake = list(enemy_snake)
                move_enemy()
                last_enemy_move_time = pygame.time.get_ticks()

                # Ravi crashes if he touches any part of the enemy snake.
                if snake[0] in enemy_snake:
                    game_over=True
                    pygame.mixer.music.stop()
                    music_playing=False
                    coin_song_playing=False
                    if coin_song: coin_song.stop()
                    if enemy_crash_song: enemy_crash_song.play()

            if e.type==RESUME:
                # Kept for compatibility; coin music is checked every frame below.
                pass

        # Resume background music only after the coin meme has completely finished.
        if coin_song_playing and (coin_song is None or coin_song.get_num_channels() == 0):
            coin_song_playing = False
            if music_playing and not game_over:
                pygame.mixer.music.unpause()

        # Speed boost wears off after BOOST_DURATION_MS.
        if boost_until and pygame.time.get_ticks() > boost_until:
            boost_until = 0
            pygame.time.set_timer(MOVE, NORMAL_MOVE_MS)
            current_move_interval = NORMAL_MOVE_MS

        draw_gradient_bg(screen)
        for x in range(0,WIDTH,CELL): pygame.draw.line(screen,GRID,(x,0),(x,HEIGHT))
        for y in range(0,HEIGHT,CELL): pygame.draw.line(screen,GRID,(0,y),(WIDTH,y))

        for x,y in walls:
            r=pygame.Rect(x*CELL,y*CELL,CELL,CELL)
            pygame.draw.rect(screen,WALL,r); pygame.draw.rect(screen,WALL2,r,2)

        cx,cy=coin; c=(cx*CELL+CELL//2,cy*CELL+CELL//2)
        pygame.draw.circle(screen,COIN,c,CELL//2-3)
        t=pygame.font.Font(None,24).render("₹",True,BLACK); screen.blit(t,t.get_rect(center=c))

        if booster is not None:
            bx,by=booster; bc=(bx*CELL+CELL//2,by*CELL+CELL//2)
            pulse = 2*abs((pygame.time.get_ticks()%600)/300-1)  # 0..2..0 pulsing size
            pts = [(bc[0]-2,bc[1]-10-pulse),(bc[0]+5,bc[1]-1),(bc[0]+1,bc[1]-1),
                   (bc[0]+3,bc[1]+10+pulse),(bc[0]-5,bc[1]+1),(bc[0]-1,bc[1]+1)]
            pygame.draw.polygon(screen,CYAN,pts)

        # Smooth gliding + a subtle slither wave, instead of snapping cell-to-cell.
        t_p = min(1.0, (pygame.time.get_ticks()-last_move_time)/current_move_interval) if (started and not game_over) else 1.0
        perp = (-direction[1], direction[0])  # perpendicular to travel, for the wave
        now_s = pygame.time.get_ticks()/1000.0

        for i,(x,y) in enumerate(snake):
            px,py = prev_snake[i] if i < len(prev_snake) else (x,y)
            lx,ly = lerp_cell((px,py),(x,y),t_p)
            px_pix, py_pix = lx*CELL, ly*CELL
            if i>0:
                wobble = math.sin(now_s*6 - i*0.8) * 2.5
                px_pix += perp[0]*wobble; py_pix += perp[1]*wobble
            r=pygame.Rect(int(px_pix)+1,int(py_pix)+1,CELL-2,CELL-2)
            pygame.draw.rect(screen,HEAD if i==0 else GREEN,r,border_radius=7)
            if i==0 and face: screen.blit(face,face.get_rect(center=r.center))
            if i==0 and boost_until: pygame.draw.rect(screen,CYAN,r,3,border_radius=7)

        # Random enemy snake — a moving obstacle. Drawn AFTER the player so its
        # face stays visible on top even on a head-on collision.
        t_e = min(1.0, (pygame.time.get_ticks()-last_enemy_move_time)/ENEMY_MOVE_MS) if (started and not game_over) else 1.0
        enemy_perp = (-enemy_direction[1], enemy_direction[0])

        for i,(x,y) in enumerate(enemy_snake):
            px,py = prev_enemy_snake[i] if i < len(prev_enemy_snake) else (x,y)
            lx,ly = lerp_cell((px,py),(x,y),t_e)
            px_pix, py_pix = lx*CELL, ly*CELL
            if i>0:
                wobble = math.sin(now_s*6 - i*0.8) * 2.5
                px_pix += enemy_perp[0]*wobble; py_pix += enemy_perp[1]*wobble
            r=pygame.Rect(int(px_pix)+1,int(py_pix)+1,CELL-2,CELL-2)
            pygame.draw.rect(screen,ENEMY_HEAD if i==0 else ENEMY_BODY,r,border_radius=7)
            if i==0:
                if enemy_face:
                    screen.blit(enemy_face,enemy_face.get_rect(center=r.center))
                else:
                    pygame.draw.circle(screen,WHITE,(r.x+8,r.y+8),3)
                    pygame.draw.circle(screen,WHITE,(r.right-8,r.y+8),3)
                    pygame.draw.circle(screen,BLACK,(r.x+8,r.y+8),1)
                    pygame.draw.circle(screen,BLACK,(r.right-8,r.y+8),1)

        draw_panel(screen, pygame.Rect(10,8,230,80))
        screen.blit(font.render(f"Score: {score}",True,WHITE),(24,16))

        if boost_until:
            remaining = max(0, boost_until - pygame.time.get_ticks())
            frac = remaining / BOOST_DURATION_MS
            bar_bg = pygame.Rect(WIDTH//2-100, 16, 200, 10)
            pygame.draw.rect(screen,(30,40,35),bar_bg,border_radius=5)
            pygame.draw.rect(screen,CYAN,(bar_bg.x,bar_bg.y,int(200*frac),10),border_radius=5)


        if not started or game_over:
            ov=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA); ov.fill((0,0,0,175)); screen.blit(ov,(0,0))

            panel_rect = pygame.Rect(WIDTH//2-260, HEIGHT//2-160, 520, 320)
            draw_panel(screen, panel_rect, radius=18)

            if not started:
                draw_text_glow(screen,"RAVI MEME SNAKE",big,WHITE,(WIDTH//2,HEIGHT//2-95),glow_color=(70,205,95),glow=2)
            else:
                draw_text_glow(screen,"RAVI GOT OUT!",big,WHITE,(WIDTH//2,HEIGHT//2-95),glow_color=RED,glow=2)

            msg="PRESS SPACE TO START" if not started else "PRESS SPACE TO PLAY AGAIN"
            blink = (pygame.time.get_ticks()//500)%2==0
            if blink:
                screen.blit(font.render(msg,True,COIN),font.render(msg,True,COIN).get_rect(center=(WIDTH//2,HEIGHT//2+40)))

        screen.blit(VIGNETTE,(0,0))
        pygame.display.flip()
        await asyncio.sleep(0)  # hands control back to the browser each frame

asyncio.run(main())
